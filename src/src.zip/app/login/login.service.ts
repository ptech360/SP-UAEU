import  { Injectable } from '@angular/core';
import { Http } from '@angular/http';
@Injectable()
export class LoginService {
value = "Login"; 
 constructor(){
 	console.log("working");
 }
}
